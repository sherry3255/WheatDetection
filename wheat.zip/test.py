import pandas as pd

train = pd.read_csv("data/train.csv")
print(train["image_id"][1])