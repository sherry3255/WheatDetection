import pandas as pd
import random
import time
import torch
import os
import numpy as np
from torch.utils.data import Dataset
import torchvision.models as models
from torch.utils.data import DataLoader
import torch.nn as nn
import torch.optim as optim
import cv2
import torchvision
import torchvision.transforms as transforms
from image import flip, color_aug
from image import get_affine_transform, affine_transform
from image import gaussian_radius, draw_umich_gaussian, draw_msra_gaussian
from image import draw_dense_reg
import math
import pose_dla_dcn
import resnet_dcn
from losses import FocalLoss
from losses import RegL1Loss, RegLoss, NormRegL1Loss, RegWeightedL1Loss
from utils import _sigmoid
from utils import _gather_feat, _transpose_and_gather_feat

# from visdom import Visdom

os.environ['CUDA_VISIBLE_DEVICES'] = '1,2,3,4'

# vis = Visdom("http://localhost")

path = "/home/horovod/data/wheat"

label_names = ['usask_1', 'arvalis_1', 'inrae_1', 'ethz_1', 'arvalis_3', 'rres_1', 'arvalis_2']

class WheatDataset(Dataset):
    mean = np.array([0.40789654, 0.44719302, 0.47026115],
                    dtype=np.float32).reshape(1, 1, 3)
    std = np.array([0.28863828, 0.27408164, 0.27809835],
                   dtype=np.float32).reshape(1, 1, 3)

    def __init__(self, train=False):
        super(WheatDataset).__init__()
        self.train = train
        self.data_csv = pd.read_csv(path + "/train.csv")
        self.images = self.data_csv.image_id.unique()

        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.ToTensor()
        ])

    def parse_bbox(self, bboxs):
        tmp = []
        for bbox in bboxs:
            bbox = bbox[1:-1]
            items = bbox.split(",")
            tmp.append([float(items[0]), float(items[1]), float(items[0]) + float(items[2]), float(items[1]) + float(items[3])])

        return np.array(tmp)

    def __getitem__(self, index):
        # index = 100
        image = self.images[index]
        data = self.data_csv[self.data_csv["image_id"] == image]
        anns = self.parse_bbox(data["bbox"].values)

        num_objs = len(anns)

        label = data["source"]
        ret = {}

        img = cv2.imread(os.path.join(path, "train", image + ".jpg"))
        
        input_h, input_w = 1024, 1024

        max_objs = 256

        img = cv2.resize(img, (input_h, input_w))
        num_classes = 1
        cls_id = 0

        show = img.copy()
        for bbox in anns:
            cv2.rectangle(show, (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3])), (255, 0, 0), 2)


        ret["show"] = show.transpose(2, 0, 1)
        ret["label"] = label_names.index(label.values[0])

        c = np.array([img.shape[1] / 2., img.shape[0] / 2.], dtype=np.float32)
        s = max(img.shape[0], img.shape[1]) * 1.0
        
        
        if self.train == True:
            sf = 0.4
            cf = 0.1
            c[0] += s * np.clip(np.random.randn() * cf, -2 * cf, 2 * cf)
            c[1] += s * np.clip(np.random.randn() * cf, -2 * cf, 2 * cf)


        inp = (img.astype(np.float32) / 255.)

        inp = (inp - self.mean) / self.std
        
        output_h = input_h // 4
        output_w = input_w // 4


        hm = np.zeros((num_classes, output_h, output_w), dtype=np.float32)
        wh = np.zeros((max_objs, 2), dtype=np.float32)


        ind = np.zeros((max_objs), dtype=np.int64)
        reg_mask = np.zeros((max_objs), dtype=np.uint8)
        reg = np.zeros((max_objs, 2), dtype=np.float32)

        draw_gaussian = draw_umich_gaussian

        for k in range(num_objs):
            bbox = np.asarray(anns[k])
            bbox = bbox / 4.0
            bbox[[0, 2]] = np.clip(bbox[[0, 2]], 0, output_w - 1)
            bbox[[1, 3]] = np.clip(bbox[[1, 3]], 0, output_h - 1)
            h, w = bbox[3] - bbox[1], bbox[2] - bbox[0]

            if h > 0 and w > 0:
                radius = gaussian_radius((math.ceil(h), math.ceil(w)))
                radius = max(0, int(radius))

                ct = np.array(
                    [(bbox[0] + bbox[2]) / 2, (bbox[1] + bbox[3]) / 2], dtype=np.float32)
                ct_int = ct.astype(np.int32)
                draw_gaussian(hm[cls_id], ct_int, radius)

                wh[k] = 1. * w, 1. * h
                ind[k] = ct_int[1] * output_w + ct_int[0]
                reg[k] = ct - ct_int
                reg_mask[k] = 1

        ret["input"] = inp.transpose([2, 0, 1])
        ret["hm"] = hm
        ret["reg_mask"] = reg_mask
        ret["ind"] = ind
        ret["wh"] = wh
        ret['reg'] = reg

        return ret

    def __len__(self):
        return len(self.images)
        

def train():
    # model = pose_dla_dcn.get_pose_net(num_layers=34, heads={'hm': 1, 'wh': 2, 'reg': 2}).cuda()
    model = resnet_dcn.get_pose_net(num_layers=18, heads={'hm': 1, 'wh': 2, 'reg': 2}, head_conv=64)

    model = torch.nn.DataParallel(model).cuda()

    trainDataset = WheatDataset(train=True)
    trainDataloader = DataLoader(trainDataset, batch_size=60, shuffle=True, num_workers=64, drop_last=True)
    optimizer = optim.SGD(model.parameters(), lr=0.0001)

    hm_critize = FocalLoss()
    wh_critize = RegL1Loss()
    reg_critize = RegL1Loss()

    for epoch in range(1000):
        for batch_index, batch in enumerate(trainDataloader):

            show = batch["show"]
            input = batch["input"].cuda()
            hm = batch["hm"].cuda()
            reg_mask = batch["reg_mask"].cuda()
            ind = batch["ind"].cuda()
            wh = batch["wh"].cuda()
            reg = batch['reg'].cuda()

            output = model(input)

            output["hm"] = _sigmoid(output["hm"])
            
            # vis.images(input, win="input", opts={ "title": "input"}) 
            hm_loss = hm_critize(output['hm'], hm)
            # if batch_index % 20 == 0:
            #     vis.images(hm, win="hm", opts={ "title": "hm"})
            #     vis.images(output['hm'], win="out_hm", opts={ "title": "out_hm"})
                # print(hm_loss)
            wh_loss = wh_critize(output['wh'], reg_mask, ind, wh)
            off_loss = reg_critize(output['reg'], reg_mask, ind, reg)

            loss = hm_loss + 0.1 * wh_loss + off_loss

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        
        torch.save(model, f"model/{epoch}.pth")



def process(img, model, name=None):
    show = img.copy()
    mean = np.array([0.40789654, 0.44719302, 0.47026115], dtype=np.float32).reshape(1, 1, 3)
    std = np.array([0.28863828, 0.27408164, 0.27809835], dtype=np.float32).reshape(1, 1, 3)

    show = img.copy()    
    img = (img / 255 - mean) / std
    img = img.transpose([2, 0, 1]).reshape(1, 3, img.shape[0], img.shape[1])
    img = torch.from_numpy(img).cuda().float()
    output = model(img)
    hm = output['hm'].sigmoid_()
    
    # vis.images(hm[0].reshape([1, 1, 256, 256]), win="pred", opts={"title":"pred"}, nrow=4)

    reg = output["reg"]

    K = 100
    heat = hm
    batch, cat, height, width = heat.size()
    heat = _nms(hm)
    scores, inds, clses, ys, xs = _topk(heat, K=K)
    reg = _transpose_and_gather_feat(reg, inds)
    reg = reg.view(batch, K, 2)

    xs = xs.view(batch, K, 1) \
         + reg[:, :, 0:1]
    ys = ys.view(batch, K, 1)\
         + reg[:, :, 1:2]

    clses = clses.view(batch, K, 1).float()[0]
    scores = scores.view(batch, K, 1)[0].squeeze()


    wh = output['wh']
    wh = _transpose_and_gather_feat(wh, inds)
    wh = wh.view(batch, K, 2)

    bboxes = torch.cat([xs - wh[..., 0:1] / 2, 
                        ys - wh[..., 1:2] / 2,
                        xs + wh[..., 0:1] / 2, 
                        ys + wh[..., 1:2] / 2], dim=2)

    bboxes = bboxes * 4
    
    scores = scores.detach().cpu().numpy()
    bboxes = bboxes.detach().cpu().numpy()
    for score in scores:
        if score < 0.9:
            continue

    return bboxes[0]

    # result = [[] for x in range(10)]

    # clses_result = []
    # clses_indexs = []

    # for i in range(100):
    #     if clses[i] not in clses_result:
    #         clses_result.append(clses[i])
    #         clses_indexs.append(i)
    #     if len(clses_result) > 10:
    #         break

    # result_str = ""
    # if len(clses_result) < 10:
    #     return "", show

    # for i in range(10):
    #     cls_index = clses_result.index(i)
    #     result_index = clses_indexs[cls_index]
    #     x, y = (scale_w * xs[0][result_index], scale_h * ys[0][result_index])
    #     cv2.circle(show, (x, y), 3, (255, 255, 0), 3)
    #     _str = ",%d,%d" % (int(x), int(y))
    #     result_str = result_str + _str
    #     # cv2.putText(show, "%d" % clses[result_index], (x - 10, y + 10), 3, 3, (0, 255, 255), 1)



def _nms(heat, kernel=3):
    pad = (kernel - 1) // 2

    hmax = nn.functional.max_pool2d(
        heat, (kernel, kernel), stride=1, padding=pad)
    keep = (hmax == heat).float()
    return heat * keep


def _topk(scores, K=40):
    batch, cat, height, width = scores.size()

    topk_scores, topk_inds = torch.topk(scores.view(batch, cat, -1), K)

    topk_inds = topk_inds % (height * width)
    topk_ys = (topk_inds / width).int().float()
    topk_xs = (topk_inds % width).int().float()

    topk_score, topk_ind = torch.topk(topk_scores.view(batch, -1), K)
    topk_clses = (topk_ind / K).int()
    topk_inds = _gather_feat(
        topk_inds.view(batch, -1, 1), topk_ind).view(batch, K)
    topk_ys = _gather_feat(topk_ys.view(batch, -1, 1), topk_ind).view(batch, K)
    topk_xs = _gather_feat(topk_xs.view(batch, -1, 1), topk_ind).view(batch, K)

    return topk_score, topk_inds, topk_clses, topk_ys, topk_xs

def test():
    model = torch.load("model/576.pth")
    model = model.module
    model = model.cuda()
    
    files_path = []
    results = []
    for root, _, files in os.walk("/home/horovod/data/wheat/test"):
        for file in files:
            img = cv2.imread(os.path.join(root, file))
            result = process(img, model, name=file)
            for r in result:
                results.append({
                    'image_id': os.path.splitext(file)[0],
                    'PredictionString':f'{r[0]} {r[1]} {r[2]} {r[3]}'
                })
    
    pd.DataFrame(results, columns=['image_id', 'PredictionString']).to_csv('submission.csv', index=False)
    


if __name__ == "__main__":
    num_layers=18
    heads={'hm': 1, 'wh': 2, 'reg': 2}
    head_conv=64

    # train(num_layers, heads, head_conv)
    test()
    